# ixia-IxN-itcl-api
This project is an object-oriented tcl api for ixia IxNetwork product which helps people who use this software to do network testing task automatically.

ixia中国自动化团队开发5年之久，现在向所有的用户及集成商开源；团队很高兴和更多的用户一起来完善这个项目，将来会有更多的项目会和大家见面；

IxiaNet他在很多的主流厂商那里运行，身经百战，是用户爱不释手的高层封装，能够帮助用户降低开发自动化脚本的难度，缩短脚本开发时间；他使用itcl语言，实现功能包括：
-连接机框
-预留端口
-配置端口属性
-流量测试
-协议仿真
-测试套件

期待你对这个项目的贡献
visit more information on www.ixiacom.com
